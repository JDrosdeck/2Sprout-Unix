/*
THIS IS AN UNPUBLISHED WORK CONTAINING 2SPROUT INC CONFIDENTIAL AND PROPRIETARY INFORMATION. 
DISCLOSURE, USE, OR REPRODUCTION WITHOUT AUTHORIZATION OF 2SPROUT INC IS STRICTLY PROHIBITED.
*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <iostream>
#include <curl/curl.h>
#include <ctype.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <queue>
#include <pthread.h>
#include <fstream>
#include <sstream>
#include <signal.h>
#include "md5.h"



/*
Includes for postgres C library
*/
#include <libpq-fe.h>
#include <iomanip>


/*
Includes for mysql C library
*/
#include <my_global.h> 
#include <my_sys.h> 
#include <mysql.h> 




using namespace std;

#define feedPipe "feedPipe"		//pipe that feeds data back through the api to the user made application
#define sproutPipe "2sprout"	//pipe that takes in api calls from the user made application
#define maxPipe		255			

#define MAXDATASIZE 1000
#define MAXBUFLEN 10000
#define MAX_BUF_SIZE 5000

//Used for md5 sum
#define MD5_CTX MD5_CTX
#define MDInit MD5Init
#define MDUpdate MD5Update
#define MDFinal MD5Final


//startFeed Vars

CURL *curl;
CURLcode res;
string url;
int MYPORT;		//port which the client is bound to 

//getData vars

bool useDatabase = true;
bool apiReadyToRecieve;

char *ipAdd;
int sockfd;
struct sockaddr_in my_addr;    // my address information
struct sockaddr_in their_addr; // connector's address information
socklen_t addr_len;
int numbytes;
char buf[MAXBUFLEN];

void getData();
queue<string> sproutFeed; //this is the queue where the approved data is located
queue<string> unprocessedData; //this is the queue for data that has yet been tested

pthread_mutex_t mylock = PTHREAD_MUTEX_INITIALIZER;
string connectionString;


const int maxArraySize = 1000;
int packetNumberCount = 0;
int packetNumbers[maxArraySize];
int lostPacketCount = 0;
int lostPackets[maxArraySize];


int temporayPacketNumbers[maxArraySize];
int temporaryNumberCount = 0;







//Used to hold database information
string database;
string host;
string port; 
string dbname;
string user;
string pass;
string table;
string col;
	
static MYSQL *conn;


string secretKey = "what"; //The Initial secretKey should be gatherd by a call made to 2sprout and gotten from our page
string currentDate = "";


/*
startFeed takes in one argument which is the string, the argument is not used right now.
The libcurl library is used to contact 2sprout.com over http using tcp protocol, for reliability.
By being directed to the webpage the ipaddress is added to the database, and feeds are then sent
to that particular client
*/
int announce(string portNumber)
{

  curl = curl_easy_init(); //initialize curl
  if(curl) 
  {
  	url = "http://2sprout.com/onClient/?port="; //access this webpage to be added to the database
    url +=portNumber;
    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());

    /* Perform the request, res will get the return code */
    res = curl_easy_perform(curl);
    curl_easy_cleanup(curl);
  }

	printf("\n"); //A messages from the server will be recieved if the client is already active
    return 1;
}




/*
This will allow users using the API to stop recieving packets. It relays a POST to the server containing its port number
it will then delete the proper value from the database based on the ip address it gathers and its port number
*/
int closeAnnounce(string portNumber)
{
	curl = curl_easy_init();
	if(curl)
	{
		url = "http://2sprout.com/client/close/?port=";
		url += portNumber;
		curl_easy_setopt(curl,CURLOPT_URL, url.c_str());
		res = curl_easy_perform(curl);
		curl_easy_cleanup(curl);
	}
	
	printf("\n"); //Will hold message from server when client is closed 
	return 1;
}

/*
The getData function acts like a port listeners, it binds itself to the specified port on the users machine
and waits to recieve packets containing feed information

*/
void* getData(void *thread_arg)
{ 	     
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) 
    {
        perror("socket");
        exit(1);
    }

    my_addr.sin_family = AF_INET;         // host byte order
    my_addr.sin_port = htons(MYPORT);     // short, network byte order
    my_addr.sin_addr.s_addr = INADDR_ANY; // automatically fill with my IP
    memset(my_addr.sin_zero, '\0', sizeof my_addr.sin_zero);


    if (bind(sockfd, (struct sockaddr *)&my_addr, sizeof my_addr) == -1) 
    {
        perror("bind");
        exit(1);
    }


	printf("Entering while\n"); 
	
 	while(1)
 	{
 
    	addr_len = sizeof their_addr;
		printf("Recieving\n");
   
    	if ((numbytes = recvfrom(sockfd, buf, MAXBUFLEN-1 , 0,(struct sockaddr *)&their_addr, &addr_len)) == -1)
    	{
        perror("recvfrom");
        exit(1);
   		}
	
	    printf("server: got connection from %s\n",inet_ntoa(their_addr.sin_addr));
        ipAdd = inet_ntoa(their_addr.sin_addr);
        printf("%s\n",ipAdd);
         
	    printf("got packet from %s\n",inet_ntoa(their_addr.sin_addr));
    	printf("packet is %d bytes long\n",numbytes);
    	buf[numbytes] = '\0';
    	printf("packet contains \"%s\"\n",buf);	
    
    
    /*
    Before putting the item in the queue read the packet number and place it in the packet Array
    Check for the md5 hashsum before stripping the packet number from the message.
    */
    
    //Put information into queue
   	    string input = buf;
    	pthread_mutex_lock(&mylock);
		unprocessedData.push(input); //pused the data into the temparary queue
    	pthread_mutex_unlock(&mylock);
     
   }
       close(sockfd);

   
}







/*
checkPacketReliablity() will check the validity of each packet and make sure that it is actually part of a 
2sprout broadcast.

format is as follows:

md5^secretKey^date^packetNumber^2sproutString


Multiple threads will run going through the unprocessed queue
Checking first the MD5 sum.
Then the secret Key 
If it passes then push it into the sproutQueue to put into the database
*/
void* checkPacketReliability(void *thread_arg)
{
	while(1)
	{
		pthread_mutex_lock(&mylock);
		if(unprocessedData.empty())
 		{
			pthread_mutex_unlock(&mylock);
		
 				if(usleep(100000) == -1)
				{
					printf("Sleeping Error");
				}
		}
		else
		{
			pthread_mutex_unlock(&mylock);
		}
		pthread_mutex_lock(&mylock);
		if(!unprocessedData.empty()) //while the queue has items
		{
			//start of critical section
			string s = unprocessedData.front();
			unprocessedData.pop();
			pthread_mutex_unlock(&mylock);	
			
			//end of critial section
			
			//Tokenize the string
			
			string token;
			string section[5]; //a standard sproutcast should be made up of only 5 distince sections	
			istringstream iss(s);
			int count1 = 0;

			
			while(getline(iss,token,'^'))
			{
				section[count1] = token;
				cout << token << endl;
				count1++;
			}
		
			
			if((section[0]  != "") && section[1] != "" && section[2] != "" && section[3] != "" && section[4] != "" ) //make sure we have all the parts
			{	
				string CastMinusMD5 = section[1] + "^" + section[2] + "^" + section[3] + "^" + section[4]; //generate the origional string to grab the MD5 sum from	
				
			
				//check the md5 sum
				string checkMd5 = MD5String(CastMinusMD5); //get the value of the MD5 string
				if(checkMd5 == section[0]) //The MD5 Sum is the same so data integrety is OK
				{
				
					printf("MD5 Just Fine! PASSED\n");
		  		
					//check the secret key
					if(section[1] == secretKey)
					{
						printf("Secret Key just fine! PASSED\n");
						
						if(currentDate == "") //this must be our first packet
							currentDate == section[2];
						else
							if(currentDate != section[2])
							{
								//the dates have changed so we should be reading to start recieving packet numbers starting at 0
								
							}
							//Add the packet Number to the array of recieved packetNumbers
				
							packetNumbers[packetNumberCount] = atoi(section[3].c_str());
						     packetNumberCount++;
						
							
							
					
					//if this passes add the packet number to the array of recieved packet numbers
			
					//Add only the message to the sproutQueue
					printf("Packet OK!!!!!!!!\n");
					pthread_mutex_lock(&mylock);
		 			sproutFeed.push(section[4]);
					pthread_mutex_unlock(&mylock);	
					}
					else{
					printf("Secret Key FAILED\n");}
				}
				else{
				printf("MD5 sum FAILED\n");}
			}
			else{
			printf("Not all data recieved FAIL!\n");}
		
		}
		else
		{
		pthread_mutex_unlock(&mylock);
		}
			
		
	}
	
	
	
}











/*
comparePacketNumbers function is called by std::qsort()
It will compare the values and return weither it is larger or smaller
*/

int comparePacketNumbers(const void * firstpacket, const void *secoundpacket)
{
	return (* (int *)firstpacket - * (int *)secoundpacket);
}




/*
TODO: umm make sure this works
Number will come in looking like month/day/year/packetNumber

keep a global variable for the day
parse out the packet number



checkPackets Goes through an ordered array of packet numbers looking for lost packets
If a packet is found to be missing use libcurl to issue a send request
*/

//TODO Fix this
void* checkLostPackets(void *thread_arg)
{
	
	while(1)
	{
		pthread_mutex_lock(&mylock);
		int oneThird = maxArraySize / 3;
		int twoThird = oneThird + oneThird;
			
		if(packetNumberCount < twoThird) // if there are not a sufficient number of packets recieved
		{
			pthread_mutex_unlock(&mylock);
			
			if(usleep(100000) == -1)
			{
				printf("Sleeping Error");
			}
		}
		else
		{
			sleep(5);
		
			//Copy the array quickly
			
		  temporaryNumberCount = packetNumberCount;
		  printf("emptying array\n");
		int j;
		  for( j = 0; j < packetNumberCount - 1; j++) //loop for 1 minus the total length
		  {
				packetNumbers[j] = '\0';
		  }
	      
		  packetNumberCount = 0;
		  memcpy(temporayPacketNumbers, packetNumbers, sizeof(temporayPacketNumbers));
		
		  pthread_mutex_unlock(&mylock);					
		
		
			//sort the array 
			printf("Sorting\n");
			qsort(temporayPacketNumbers, sizeof(temporayPacketNumbers), sizeof(int), comparePacketNumbers);
			printf("Sorting complete\n");
			
			int i;
			int temp1;
			int temp2;
			int remainder;
			int lostPacket;
			printf("Comparing\n");
	
			for( i = 1; i < temporaryNumberCount; i++) //loop for 1 minus the total length
			{
				
				printf("temp %i\n", temporayPacketNumbers[i]);
				
				/*
				temp1 = packetNumbers[i];
				temp2 = packetNumbers[i+1];
				remainder = temp2 - temp1; //this will give the exact number of lost packets 
				
				printf("temp1 %i\n", temp1);
				printf("temp2 %i\n", temp2);
				printf("Remainder is: %i\n", remainder);
			
				curl = curl_easy_init(); //initialize curl
				while ( remainder != 0)
				{
					lostPacket = temp1 + remainder;
				
  					if(curl) 
					{	
    					url = "http://2sprout.com/lostPacket/?port="; //access this webpage to be added to the database
    					url += lostPacket;
   						curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    				// Perform the request, res will get the return code/
    					res = curl_easy_perform(curl);
    			
						//Add the lost packets to the lostPacket array
						lostPackets[lostPacketCount] = lostPacket;	
						lostPacketCount++;
						
    					if(usleep(100000) == -1)
						{
							printf("Sleeping Error");
						}	
    				}
    			curl_easy_cleanup(curl);
				remainder --;
				}
				
				*/
			}
				//Clear out the array
		
		}
	}
}















/*
insertToDb relays the information recieved from the listener
into the database
*/

void* insertToDb(void *thread_arg)
{
	if(database == "postgres")
	{

		connectionString = "host=" + host + " port=" + port + " dbname=" + dbname + " user=" + user + " password=" + pass;
		PGconn *Conn = PQconnectdb(connectionString.c_str());
		PGresult* result;
		
		if (PQstatus(Conn) == CONNECTION_BAD)
    	{
        	fprintf(stderr,"Failed to connect to database\n");
        	fprintf(stderr,"%s\n",PQerrorMessage(Conn));
        	PQfinish(Conn);
        	exit(1);
    	}

 		while(1)
 		{
			pthread_mutex_lock(&mylock);
 			if(sproutFeed.empty())
	 		{
				pthread_mutex_unlock(&mylock);
		
				if(usleep(100000) == -1)
				{
					printf("Sleeping Error");
				}	
			}
			else
			{
				pthread_mutex_unlock(&mylock);
				
			}
			
			
			pthread_mutex_lock(&mylock);
			if(!sproutFeed.empty()) //while the queue has items
			{
				//start of critical section
				string s = sproutFeed.front();
				printf("read in: %s\n", s.c_str());
				printf("Putting into Database\n");
				pthread_mutex_unlock(&mylock);
				//end of critical section
				string escapedString;
				int *error;
		 		unsigned long g = PQescapeStringConn(Conn, (char *)escapedString.c_str(), (char *)s.c_str(), strlen(s.c_str()),error);  
				cout << "Escaped String " << escapedString.c_str() << endl;
	   			try
	    		{
	  				// (Queries)
	  				string Query = "INSERT INTO ";
	  				Query = Query + "\""+ table + "\"" + " (" + col + ") " + "VALUES('";	
	  				Query = Query + escapedString.c_str();
	  				Query = Query +"');";
	  				cout << Query << endl;
	    			result = PQexec(Conn,Query.c_str());
					if (PQresultStatus(result) != PGRES_COMMAND_OK) 
					{
				             fprintf(stderr,"BEGIN command failed");
				             PQclear(result);
				    }
				  
					
					PQclear(result);
					printf("CLEAR!!!!!!!!!!!!!!!!!");
					sproutFeed.pop();
					
	
				}
	    		catch (...)
	    		{
	    			//i failed...um fuck it
	    		}
	    

			}
			else
			{
				pthread_mutex_unlock(&mylock);
				
			}
		//PQfinish(Conn);
		}
	}


	if(database == "mysql")
	{
    	if (mysql_library_init(0,NULL,NULL))
		{
			cout << "Library init failed" << endl;
			exit(1);
		}
		
		conn = mysql_init (NULL);
	
    	if(conn == NULL)
    	{
    		cout << "Mysql initiation failed" << endl;
    		exit(1);
    	}
    
 
    	if(mysql_real_connect(conn, (char *)host.c_str(), (char *)user.c_str(), (char *)pass.c_str(), (char *)dbname.c_str(), atoi(port.c_str()), NULL,0) == NULL)
    	{
    		cout << "connection to server failed" << endl;
    		mysql_close(conn);
    		exit(1);
    	}
    
    	while(1)
 		{
			pthread_mutex_lock(&mylock);
		
 			if(sproutFeed.empty())
 			{
 				pthread_mutex_unlock(&mylock);
				
				if(usleep(100000) == -1)
				{
					printf("Sleeping Error");
				}
			}
			else
			{
				pthread_mutex_unlock(&mylock);
			}
		
			pthread_mutex_lock(&mylock);
		
			if(!sproutFeed.empty()) //while the queue has items
			{
				//start of critical section
				string s = sproutFeed.front();
				printf("read in: %s\n", s.c_str());
				printf("Putting into Database\n");
				pthread_mutex_unlock(&mylock);
				//end of critical section
		 		string escapedString;    
    			string mysqlQuery;
		   
		   
		  		unsigned long to_len = mysql_real_escape_string (conn, (char *)escapedString.c_str(), (char *)s.c_str(), strlen(s.c_str()));	//use the built in mysql function to put in escape characters...if ther are any	
				mysqlQuery = "INSERT INTO " + table + " ("+ col +") VALUES (\"" + escapedString.c_str() + "\");"; //actual creation of the sql statment
 				cout << mysqlQuery << endl;
 				if(mysql_query(conn, mysqlQuery.c_str()) != 0)
 		  		{
 		   			cout << "error query failed" << endl;
          		}
          
          		sproutFeed.pop();
			}
			else
			{
				pthread_mutex_unlock(&mylock);		
			}
    
		}    
		mysql_close(conn); //close the database connection
   	    mysql_library_end(); //stop using the library

	}

}   
   
   

   
/*
ReadConfig function, Goes through the 2sprout.conf file and reads in all the appropriate information 
used to create a connection with a database.
*/
 int readConfig()
 {
    int i;
    int command = 0; //used to keep track of what command has been read it
 	string line;
 	int found =0;
 	ifstream sproutConfig("2sprout.conf");
 	if(sproutConfig.is_open())
 	{
 		while(!sproutConfig.eof())
 		{
 			getline(sproutConfig,line);
 			if(!line.empty())
 			{
 		 	found = 0;

 			for(i = 0; i< line.length(); i++)
 			{
 				if(found == 0)
 				{
 					if(line.at(i) != ' ')
 					{
 						if(line.at(i) == '#')
 						{
 							break;
 						}
 						else
 						{
 						if(command == 0)
 						{
 							database = line;
 							found = 1;
 						}
 						if(database == "postgres")
 						{
 							if(command == 1)
 							{
 								host = line;
 								found = 1;
 							}
 							if(command == 2)
 							{
 								port = line;
 								found = 1;
 							}
 							if(command == 3)
 							{
 								dbname = line;
 								found = 1;
 							}
 							if(command == 4)
 							{
 								user = line;
 								found = 1;
 							}
 							if(command == 5)
 							{
 								pass = line;
 								found = 1;
 							}
 							if(command == 6)
 							{
 								table = line;
 								found = 1;
 							}
 							if(command == 7)
 							{
 								col = line;
 								found = 1;
 							}
 						}
 					else if(database == "mysql")
 					{
 						if(command == 1)
 							{
 								host = line;
 								found = 1;
 							}
 							if(command == 2)
 							{
 								port = line;
 								found = 1;
 							}
 							if(command == 3)
 							{
 								dbname = line;
 								found = 1;
 							}
 							if(command == 4)
 							{
 								user = line;
 								found = 1;
 							}
 							if(command == 5)
 							{
 								pass = line;
 								found = 1;
 							}
 							if(command == 6)
 							{
 								table = line;
 								found = 1;
 							}
 							if(command == 7)
 							{
 								col = line;
 								found = 1;
 							}
 					}
 					
 					else if(database == "none")
 					{
 						useDatabase = false;
 					
 					}
 					
 					command ++;
  					break;
  					}		
 				}
 				}
 			}
 			}
 			
 		}
 		sproutConfig.close();
 	}
 
 return 1;
 
 }
 
 
 
 
 
 
 
 
/*
getFeed is an API function It allows users to not relay information directly into a database
but rather gives them access to the data via their own queue within the 2sprout library. 
Information is passed through the api via named pipes
*/
  
 void* getFeed(void *thread_arg)
{
	printf("Waiting to transmit Packets\n");
	int fd, ret_val, count, numread;

	printf("creating pipe for data transmission");

	
	ret_val = mkfifo(feedPipe, 0777); //create the pipe that will be used for transfering data back to user made app
	
	if (( ret_val == -1) && (errno != EEXIST)) 
	{
		perror("Error creating named pipe");
		exit(1);
	}
	
	while(1)
	{	
		if(usleep(100000) == -1)
		{
			printf("Sleeping Error");
		}			
		if(apiReadyToRecieve == true)
		{
			if(!sproutFeed.empty())
			{
				printf("NOT EMPTY \n");
				//start of critcal section
				pthread_mutex_lock(&mylock);
				string s = sproutFeed.front() + "\n";
				//check the packet here
				sproutFeed.pop();
				pthread_mutex_unlock(&mylock);
				//end of critical section
				fd = open(feedPipe, O_WRONLY); //open the pipe for writing
				write(fd,s.c_str(),strlen(s.c_str())); 	//write the string to the pipe
				close(fd); //close the connection to the pipe
			}
		}
	}
}
 
 

 
 
 /*
 createAndReadPipe creates the pipe and then constantly reads
 waiting for calls from the API's
 */
 void* createAndReadPipe(void *thread_arg)
{

	int fd, ret_val, count, numread;
	char bufpipe[maxPipe];
	char copyPipe[maxPipe];
	string word;
	
	ret_val = mkfifo(sproutPipe, 0777); //make the sprout pipe
	
	if (( ret_val == -1) && (errno != EEXIST)) 
	{
		perror("Error creating named pipe");
		exit(1);
	}
	
	fd = open(sproutPipe, O_RDONLY); //open the pipe for reading
	
	while(1)
	{
		numread = read(fd,bufpipe, maxPipe);
		if(numread > 1)
		{
			bufpipe[numread] = '\0';
			printf("%s\n", bufpipe);
			word = bufpipe; 
			string token;
			string command[10];	//messages passed through can have a maximum of 10 arguments. (should never be more then that)
			istringstream iss(word);
			int count1 = 0;
			
			
			/*
			This will tokenize the string and figure out what commands and arguments have been passed through from the API
			It will then call the specified functions with their arguments
			*/
			
			while(getline(iss,token,' '))
			{
				command[count1] = token;
				cout << token << endl;
				count1++;
			}
		
		
			if(command[0] == "stopFeed")
			{
				closeAnnounce(command[1]);
			}	
	
			if(command[0] == "startFeed")
			{
				announce(command[1]);
			}
	
			if(command[0] == "getFeed")
			{
				apiReadyToRecieve = true;
				printf("done\n");
			}

		}

	}
}
 
 
  
/*
TODO: Have the named pipes in a seperate folder within the main client directory.


sproutClient takes 1 argument, which is the port number, This will be upated for username/password.
The defualt port used is 4950, otherwise set it to the user specified port. Once the port number
is relayed to the webserver the threads start for pening the UDP listener and Inserting data into the 
database
*/
int main(int argc, char *argv[])
{
	apiReadyToRecieve = false;
	if(argc < 2)
	{
		char port1[] = "4950";
		argv[1] = port1;	
	}
	
	//check to see if the port number is less then 1024 (reserved ports)
	
	if(atoi(argv[1]) <= 1024)
	{
		printf("Port Number is system reserved: Must be greater then 1024\n");
		exit(1);	
	}
	
	
	readConfig(); 	//read the configuration file for database access.
	
    if(useDatabase == true)
    {
		MYPORT = atoi(argv[1]); //set the port
		announce(argv[1]); //announce to the server that we're ready to recieve
    	int rc, i , status;
		pthread_t threads[8];
		printf("Starting Threads...\n");
		pthread_create(&threads[0], NULL, getData, NULL);
		printf("Socket Thread Started\n");
		pthread_create(&threads[1], NULL, insertToDb, NULL);		
		printf("InsertDB Thread Started\n");
		pthread_create(&threads[2], NULL, createAndReadPipe, NULL);
		printf("pipethread started \n");		
		pthread_create(&threads[3], NULL, checkPacketReliability, NULL);
		pthread_create(&threads[4], NULL, checkPacketReliability, NULL);
		pthread_create(&threads[5], NULL, checkPacketReliability, NULL);	
		pthread_create(&threads[6], NULL, checkPacketReliability, NULL);	
		pthread_create(&threads[7], NULL, checkPacketReliability, NULL);
		
	//	pthread_create(&threads[8], NULL, checkLostPackets, NULL);
		
		
		printf("Checking Packets \n");
		
		

		for(i =0; i < 8; i++)
		{
			rc = pthread_join(threads[i], (void **) &status); 
		}
		
		return 0;
	}
	
	/*
	If useDatabase is set to false Then the user is going to be using the sdk to interact with the feed
	Instead of announcing, and capturing data, just set up the pipe to allow api access
	*/
	else
	{
		printf("Not using Database\n");
		MYPORT = atoi(argv[1]); //set the port value
		announce(argv[1]); //announce to the server that we're ready to recieve
		int rc, i , status;
		pthread_t threads[8];
		printf("Starting Threads...\n");
		pthread_create(&threads[0], NULL, getData, NULL);
		pthread_create(&threads[1], NULL, createAndReadPipe, NULL);
		pthread_create(&threads[2], NULL, getFeed, NULL);
		pthread_create(&threads[3], NULL, checkPacketReliability, NULL);	
		pthread_create(&threads[4], NULL, checkPacketReliability, NULL);		
		pthread_create(&threads[5], NULL, checkPacketReliability, NULL);
		pthread_create(&threads[6], NULL, checkPacketReliability, NULL);
		pthread_create(&threads[7], NULL, checkPacketReliability, NULL);
		
		printf("Checking Packets \n");
		
		pthread_create(&threads[8], NULL, checkPacketReliability, NULL);
		for(i =0; i < 8; i++)
		{
			rc = pthread_join(threads[i], (void **) &status); 
		}
	}
}


   
   


